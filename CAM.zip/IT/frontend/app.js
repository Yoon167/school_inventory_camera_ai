const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const qrResult = document.getElementById('qr-result');
const itemDetails = document.getElementById('item-details');
const itemName = document.getElementById('item-name');
const itemDescription = document.getElementById('item-description');
const itemQuantity = document.getElementById('item-quantity');
const itemLocation = document.getElementById('item-location');

const canvasContext = canvas.getContext('2d');
let scanning = false;

// Load jsQR library dynamically
function loadJsQR() {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js';
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load jsQR library'));
    document.head.appendChild(script);
  });
}

// Camera and QR scanning functions
function startCamera() {
  navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
    .then(function(stream) {
      video.srcObject = stream;
      video.setAttribute('playsinline', true);
      video.play();
      scanning = true;
      requestAnimationFrame(tick);
    })
    .catch(function(err) {
      qrResult.textContent = 'Error accessing camera: ' + err.message;
    });
}

function tick() {
  if (video.readyState === video.HAVE_ENOUGH_DATA) {
    canvas.height = video.videoHeight;
    canvas.width = video.videoWidth;
    canvasContext.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = canvasContext.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: 'dontInvert',
    });
    if (code) {
      scanning = false;
      video.srcObject.getTracks().forEach(track => track.stop());
      qrResult.textContent = 'QR Code detected: ' + code.data;
      fetchItemByQR(code.data);
      return;
    } else {
      qrResult.textContent = 'Scanning for QR code...';
    }
  }
  if (scanning) {
    requestAnimationFrame(tick);
  }
}

function fetchItemByQR(qrCode) {
  fetch('http://localhost:3000/api/items/qr/' + encodeURIComponent(qrCode))
    .then(response => {
      if (!response.ok) {
        throw new Error('Item not found');
      }
      return response.json();
    })
    .then(item => {
      itemDetails.hidden = false;
      itemName.textContent = item.name;
      itemDescription.textContent = item.description;
      itemQuantity.textContent = item.quantity;
      itemLocation.textContent = item.location;
    })
    .catch(err => {
      qrResult.textContent = err.message;
      itemDetails.hidden = true;
    });
}

// Register new item form handling - FIXED VERSION
const registerForm = document.getElementById('register-form');
const registerMessage = document.getElementById('register-message');

registerForm.addEventListener('submit', function(event) {
  event.preventDefault();

  const name = document.getElementById('name').value.trim();
  const description = document.getElementById('description').value.trim();
  const quantity = parseInt(document.getElementById('quantity').value, 10);
  const location = document.getElementById('location').value.trim();
  const qr_code = document.getElementById('qr_code').value.trim();

  // Validate inputs
  if (!name || !qr_code || isNaN(quantity) || quantity < 0) {
    registerMessage.textContent = 'Please fill in all required fields correctly.';
    registerMessage.style.color = 'red';
    return;
  }

  // Prepare data
  const itemData = {
    name: name,
    description: description || '',
    quantity: quantity,
    location: location || '',
    qr_code: qr_code
  };

  // Send registration request
  fetch('http://localhost:3000/api/items', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(itemData)
  })
  .then(response => {
    if (!response.ok) {
      return response.json().then(err => {
        throw new Error(err.error || 'Failed to register item');
      });
    }
    return response.json();
  })
  .then(data => {
    registerMessage.textContent = 'Item registered successfully!';
    registerMessage.style.color = 'green';
    registerForm.reset();
    
    // Optional: Show QR code info
    console.log('Registered item:', data);
  })
  .catch(error => {
    console.error('Registration error:', error);
    registerMessage.textContent = 'Error: ' + error.message;
    registerMessage.style.color = 'red';
  });
});

// Initialize camera on load
loadJsQR()
  .then(() => {
    startCamera();
  })
  .catch(err => {
    qrResult.textContent = err.message;
  });
