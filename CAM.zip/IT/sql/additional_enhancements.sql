-- Additional SQL enhancements for the school inventory system
-- These are optional improvements based on program usage patterns

-- 1. Performance indexes for common queries
CREATE INDEX IF NOT EXISTS idx_inventory_qr_code ON inventory(qr_code);
CREATE INDEX IF NOT EXISTS idx_inventory_name ON inventory(name);
CREATE INDEX IF NOT EXISTS idx_inventory_location ON inventory(location);

-- 2. Trigger for automatic updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_inventory_updated_at BEFORE UPDATE ON inventory
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 3. Optional audit table for tracking changes
CREATE TABLE IF NOT EXISTS inventory_audit (
    audit_id SERIAL PRIMARY KEY,
    inventory_id INTEGER REFERENCES inventory(id),
    action VARCHAR(10) NOT NULL,
    old_values JSONB,
    new_values JSONB,
    changed_by VARCHAR(255),
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. View for inventory reporting
CREATE OR REPLACE VIEW inventory_summary AS
SELECT 
    location,
    COUNT(*) as item_count,
    SUM(quantity) as total_quantity
FROM inventory
GROUP BY location;

-- 5. Additional constraints for data integrity
ALTER TABLE inventory 
ADD CONSTRAINT positive_quantity CHECK (quantity >= 0);

-- 6. Index for date-based queries
CREATE INDEX IF NOT EXISTS idx_inventory_created_at ON inventory(created_at);
CREATE INDEX IF NOT EXISTS idx_inventory_updated_at ON inventory(updated_at);
