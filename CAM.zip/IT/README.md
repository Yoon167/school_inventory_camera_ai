# School Inventory Management System

A comprehensive inventory management system designed for schools and educational institutions, featuring QR code scanning, real-time tracking, and intuitive web interface.

## 🚀 Features

- **QR Code Integration**: Scan and link items to unique QR codes
- **Real-time Inventory Tracking**: Monitor stock levels and locations
- **Responsive Web Interface**: Works on desktop, tablet, and mobile devices
- **Database Optimization**: Indexed queries for fast performance
- **Audit Trail**: Track all changes to inventory items
- **RESTful API**: Clean backend architecture with Express.js

## 🛠️ Technology Stack

- **Backend**: Node.js, Express.js
- **Database**: PostgreSQL
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **QR Scanning**: jsQR library with camera integration
- **Deployment**: Ready for Heroku, Railway, or VPS

## 📦 Installation

### Prerequisites
- Node.js (v14 or higher)
- PostgreSQL (v12 or higher)
- Git

### 1. Clone the Repository
```bash
git clone https://github.com/Yoon167/school_inventory_camera_ai.git
cd school-inventory-system
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Database Setup
```bash
# Create database
createdb school_inventory

# Run schema
psql -d school_inventory -f sql/create_inventory_table.sql

# Optional: Run performance enhancements
psql -d school_inventory -f sql/additional_enhancements.sql
```

### 4. Environment Configuration
Create a `.env` file in the backend directory:
```env
DATABASE_URL=postgresql://wang:monster12345@localhost:5432/school_inventory
PORT=3000
```

### 5. Start the Application
```bash
# Development
npm run dev

# Production
npm start
```

## 🎯 Usage

### Adding New Items
1. Navigate to the registration form
2. Fill in item details (name, description, quantity, location)
3. Generate or scan a QR code
4. Submit to add to inventory

### Scanning Items
1. Allow camera access when prompted
2. Point camera at item QR code
3. View item details instantly
4. Update quantity or location as needed

### Managing Inventory
- Use the web interface to browse all items
- Search and filter by location, name, or QR code
- Update item details in real-time
- Track all changes with audit trail

## 🔧 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/items | Get all inventory items |
| GET | /api/items/qr/:qr_code | Get item by QR code |
| POST | /api/items | Add new inventory item |
| PUT | /api/items/:id | Update existing item |
| DELETE | /api/items/:id | Delete item from inventory |

## 📱 Mobile Support

The system is fully responsive and works seamlessly on:
- iOS Safari (iPhone/iPad)
- Android Chrome
- Desktop browsers (Chrome, Firefox, Safari, Edge)

## 🗄️ Database Schema

```sql
CREATE TABLE inventory (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  quantity INTEGER DEFAULT 0,
  location VARCHAR(255),
  qr_code VARCHAR(255) UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👥 Support

For support, email support@school-inventory.com or create an issue in the GitHub repository.

## 🙏 Acknowledgments

- Built for educational institutions worldwide
- Designed with teachers and administrators in mind
- Powered by open-source technologies
