const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// API routes
// Catch-all route should be last to avoid conflicts with API routes

// Create inventory table if not exists
const createTableQuery = "CREATE TABLE IF NOT EXISTS inventory (" +
  "id SERIAL PRIMARY KEY, " +
  "name VARCHAR(255) NOT NULL, " +
  "description TEXT, " +
  "quantity INTEGER DEFAULT 0, " +
  "location VARCHAR(255), " +
  "qr_code VARCHAR(255) UNIQUE, " +
  "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
  "updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
");";

db.query(createTableQuery)
  .then(function() {
    console.log('Inventory table is ready');
  })
  .catch(function(err) {
    console.error('Error creating table', err);
  });

// Get all items
app.get('/api/items', function(req, res) {
  db.query('SELECT * FROM inventory ORDER BY id')
    .then(function(result) {
      res.json(result.rows);
    })
    .catch(function(err) {
      res.status(500).json({ error: err.message });
    });
});

// Get item by QR code
app.get('/api/items/qr/:qr_code', function(req, res) {
  var qr_code = req.params.qr_code;
  db.query('SELECT * FROM inventory WHERE qr_code = $1', [qr_code])
    .then(function(result) {
      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Item not found' });
      }
      res.json(result.rows[0]);
    })
    .catch(function(err) {
      res.status(500).json({ error: err.message });
    });
});

// Add new item
app.post('/api/items', function(req, res) {
  var name = req.body.name;
  var description = req.body.description;
  var quantity = req.body.quantity;
  var location = req.body.location;
  var qr_code = req.body.qr_code;

  var insertQuery = 'INSERT INTO inventory (name, description, quantity, location, qr_code) VALUES ($1, $2, $3, $4, $5) RETURNING *';
  var values = [name, description, quantity, location, qr_code];

  db.query(insertQuery, values)
    .then(function(result) {
      res.status(201).json(result.rows[0]);
    })
    .catch(function(err) {
      res.status(500).json({ error: err.message });
    });
});

// Update item by id
app.put('/api/items/:id', function(req, res) {
  var id = req.params.id;
  var name = req.body.name;
  var description = req.body.description;
  var quantity = req.body.quantity;
  var location = req.body.location;
  var qr_code = req.body.qr_code;

  var updateQuery = 'UPDATE inventory SET name=$1, description=$2, quantity=$3, location=$4, qr_code=$5, updated_at=NOW() WHERE id=$6 RETURNING *';
  var values = [name, description, quantity, location, qr_code, id];

  db.query(updateQuery, values)
    .then(function(result) {
      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Item not found' });
      }
      res.json(result.rows[0]);
    })
    .catch(function(err) {
      res.status(500).json({ error: err.message });
    });
});

// Delete item by id
app.delete('/api/items/:id', function(req, res) {
  var id = req.params.id;
  db.query('DELETE FROM inventory WHERE id=$1 RETURNING *', [id])
    .then(function(result) {
      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Item not found' });
      }
      res.json({ message: 'Item deleted' });
    })
    .catch(function(err) {
      res.status(500).json({ error: err.message });
    });
});

// Catch-all route to serve index.html for SPA support - must be last
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(port, function() {
  console.log('Server running on http://localhost:' + port);
});
