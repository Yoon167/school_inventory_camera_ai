const { Pool } = require('pg');

const pool = new Pool({
  user: 'wang',
  host: 'localhost',
  database: 'school_inventory',
  password: 'monster12345', // Replace with your actual PostgreSQL password as a string
  port: 5432,
});

module.exports = {
  query: (text, params) => pool.query(text, params),
};
